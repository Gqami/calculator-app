import React, { useState } from 'react';
import { Text, TextInput, View, Button, Alert } from 'react-native';

export default function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState('');

  const validateInput = (value) => {
    if (isNaN(value) || value.trim() === '') {
      return false;
    }
    return true;
  };

  const handleOperation = (operation) => {
    if (!validateInput(num1) || !validateInput(num2)) {
      Alert.alert('Invalid input', 'Please enter valid numbers.');
      return;
    }

    const number1 = parseFloat(num1);
    const number2 = parseFloat(num2);

    let res;
    switch (operation) {
      case 'add':
        res = number1 + number2;
        break;
      case 'subtract':
        res = number1 - number2;
        break;
      case 'multiply':
        res = number1 * number2;
        break;
      case 'divide':
        res = number1 / number2;
        break;
      case 'power':
        res = Math.pow(number1, number2);
        break;
      case 'sqrt':
        res = Math.sqrt(number1); 
        break;
      default:
        res = 'Error';
    }

    setResult(res.toString());
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 10, paddingHorizontal: 10 }}
        placeholder="Enter first number"
        keyboardType="numeric"
        value={num1}
        onChangeText={setNum1}
      />
      <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 10, paddingHorizontal: 10 }}
        placeholder="Enter second number"
        keyboardType="numeric"
        value={num2}
        onChangeText={setNum2}
      />
      <Button title="Add" onPress={() => handleOperation('add')} />
      <Button title="Subtract" onPress={() => handleOperation('subtract')} />
      <Button title="Multiply" onPress={() => handleOperation('multiply')} />
      <Button title="Divide" onPress={() => handleOperation('divide')} />
      <Button title="Power" onPress={() => handleOperation('power')} />
      <Button title="Square Root" onPress={() => handleOperation('sqrt')} />
      <Text style={{ marginTop: 20, fontSize: 20 }}>Result: {result}</Text>
    </View>
  );
}